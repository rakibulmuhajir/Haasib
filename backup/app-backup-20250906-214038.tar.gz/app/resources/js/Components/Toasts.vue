<script setup lang="ts">
// No-op placeholder during migration: toasts now use PrimeVue's ToastService.
// This component remains mounted temporarily to avoid layout churn.
</script>

<template>
  <!-- Intentionally empty: PrimeVue <Toast /> is mounted globally in the layout. -->
</template>
