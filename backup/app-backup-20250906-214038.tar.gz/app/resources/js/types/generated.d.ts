declare namespace App.Enums {
export type CompanyRole = 'owner' | 'admin' | 'accountant' | 'viewer';
}
