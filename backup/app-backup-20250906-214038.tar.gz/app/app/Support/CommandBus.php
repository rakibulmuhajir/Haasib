<?php

namespace App\Support;

use App\Models\User;

class CommandBus
{
    public function dispatch(string $action, array $params, User $user): array
    {
        $handlers = config('command-bus');
        $handlerClass = $handlers[$action] ?? null;

        if (! $handlerClass) {
            throw new \InvalidArgumentException("Unknown action: {$action}");
        }

        return app($handlerClass)->handle($params, $user);
    }
}
